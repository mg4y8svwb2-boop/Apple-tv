package com.example.cinematv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 44;
    private SharedPreferences prefs;
    private Uri wallpaperUri;
    private LinearLayout root, dock, grid;
    private FrameBackground background;
    private final List<AppItem> apps = new ArrayList<>();
    private final List<String> favorites = new ArrayList<>();
    private final int cyan = Color.rgb(106, 220, 255);

    static class AppItem {
        String label, pkg;
        Drawable icon;
        Intent intent;
        AppItem(String l, String p, Drawable i, Intent in) { label=l; pkg=p; icon=i; intent=in; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cinema", MODE_PRIVATE);
        String saved = prefs.getString("wallpaper", null);
        if (saved != null) {
            try { wallpaperUri = Uri.parse(saved); getContentResolver().takePersistableUriPermission(wallpaperUri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
        }
        loadApps();
        buildUI();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent leanback = new Intent(Intent.ACTION_MAIN); leanback.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(leanback, 0);
        if (found.isEmpty()) {
            Intent launch = new Intent(Intent.ACTION_MAIN); launch.addCategory(Intent.CATEGORY_LAUNCHER);
            found = pm.queryIntentActivities(launch, 0);
        }
        Collections.sort(found, new Comparator<ResolveInfo>() {
            public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        for (ResolveInfo r : found) {
            String p = r.activityInfo.packageName;
            if (p.equals(getPackageName())) continue;
            boolean duplicate=false;
            for(AppItem a: apps) if(a.pkg.equals(p)) { duplicate=true; break; }
            if(duplicate) continue;
            Intent launch = new Intent(Intent.ACTION_MAIN);
            launch.addCategory(Intent.CATEGORY_LAUNCHER);
            launch.setPackage(p);
            List<ResolveInfo> launchables = pm.queryIntentActivities(launch, 0);
            if (launchables.isEmpty()) {
                launch = new Intent(Intent.ACTION_MAIN); launch.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER); launch.setPackage(p);
                launchables = pm.queryIntentActivities(launch, 0);
            }
            if (!launchables.isEmpty()) {
                ResolveInfo ri=launchables.get(0);
                Intent go = new Intent(Intent.ACTION_MAIN);
                go.addCategory(ri.activityInfo.category == null ? Intent.CATEGORY_LAUNCHER : Intent.CATEGORY_LAUNCHER);
                go.setClassName(ri.activityInfo.packageName, ri.activityInfo.name);
                apps.add(new AppItem(r.loadLabel(pm).toString(), p, r.loadIcon(pm), go));
            }
        }
    }

    private void buildUI() {
        background = new FrameBackground();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(26), dp(18), dp(26), dp(12));
        root.setBackgroundColor(Color.rgb(7,17,30));
        background.addView(root, new ViewGroup.LayoutParams(-1,-1));
        setContentView(background);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("CINEMA TV", 17, Color.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(44), 1));
        TextView clock = text("YOUR HOME  •  APPS  •  WALLPAPER", 12, Color.WHITE, true);
        clock.setAlpha(.78f);
        top.addView(clock);
        root.addView(top);

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1,0,1));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        TextView headline = text("Your screen. Your cinema.", 24, Color.WHITE, true);
        controls.addView(headline, new LinearLayout.LayoutParams(0, dp(46), 1));
        TextView wallpaper = pill("CHANGE WALLPAPER");
        wallpaper.setOnClickListener(v -> chooseWallpaper());
        controls.addView(wallpaper);
        root.addView(controls);

        TextView hint = text("Choose an app to start watching", 13, Color.WHITE, false);
        hint.setAlpha(.78f);
        root.addView(hint);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dock.setPadding(dp(8),dp(8),dp(8),dp(8));
        dock.setBackground(round(Color.argb(125,225,237,248), dp(26), Color.argb(110,255,255,255), dp(1)));
        hsv.addView(dock);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(118));
        hp.topMargin = dp(14);
        root.addView(hsv,hp);

        TextView allTitle = text("ALL APPS", 13, Color.WHITE, true);
        allTitle.setLetterSpacing(.12f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(32));
        tp.topMargin = dp(12);
        root.addView(allTitle,tp);

        ScrollView scroll = new ScrollView(this);
        grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        scroll.setFillViewport(false); scroll.addView(grid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        populateApps();
    }

    private void populateApps() {
        dock.removeAllViews(); grid.removeAllViews();
        int dockCount = Math.min(6, apps.size());
        for(int i=0;i<dockCount;i++) dock.addView(appCard(apps.get(i), true));
        if (apps.isEmpty()) {
            TextView none = text("No launchable apps found. Check Android TV app permissions.", 16, Color.WHITE, true);
            grid.addView(none);
            return;
        }
        int columns = 5;
        for(int start=0; start<apps.size(); start+=columns) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            for(int j=start;j<Math.min(start+columns,apps.size());j++) row.addView(appCard(apps.get(j), false), new LinearLayout.LayoutParams(0,dp(92),1));
            for(int k=Math.min(columns, apps.size()-start);k<columns;k++) row.addView(new View(this),new LinearLayout.LayoutParams(0,dp(92),1));
            grid.addView(row);
        }
    }

    private View appCard(AppItem app, boolean isDock) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setFocusable(true);
        card.setClickable(true);
        card.setPadding(dp(6),dp(6),dp(6),dp(6));
        card.setBackground(round(Color.argb(isDock?95:65,12,22,37),dp(18),Color.argb(80,255,255,255),dp(1)));
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(app.icon);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        card.addView(icon,new LinearLayout.LayoutParams(dp(isDock?55:38),dp(isDock?55:38)));
        TextView label = text(app.label, isDock?11:10, Color.WHITE, true);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(1);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(22));
        lp.topMargin=dp(4);
        card.addView(label,lp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(isDock?126:0),dp(isDock?94:86),isDock?0:1);
        cp.setMargins(dp(4),dp(4),dp(4),dp(4));
        card.setOnClickListener(v -> {
            try { startActivity(app.intent); }
            catch(Exception e) { Toast.makeText(this,"Can't open "+app.label,Toast.LENGTH_SHORT).show(); }
        });
        card.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused?1.08f:1f).scaleY(focused?1.08f:1f).setDuration(140).start();
            v.setBackground(round(Color.argb(focused?210: (isDock?95:65), focused?15:12,focused?55:22,focused?75:37),dp(18),focused?cyan:Color.argb(80,255,255,255),dp(focused?2:1)));
        });
        card.setOnKeyListener((v,key,event)-> {
            if(event.getAction()==KeyEvent.ACTION_DOWN && key==KeyEvent.KEYCODE_MENU) { chooseWallpaper(); return true; }
            return false;
        });
        card.setLayoutParams(cp);
        return card;
    }

    private void chooseWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, PICK_WALLPAPER); }
        catch(Exception e) { Toast.makeText(this,"Wallpaper picker is unavailable on this device",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_WALLPAPER && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            wallpaperUri=data.getData();
            try { getContentResolver().takePersistableUriPermission(wallpaperUri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            prefs.edit().putString("wallpaper",wallpaperUri.toString()).apply();
            background.invalidate();
        }
    }

    private TextView pill(String s) {
        TextView t=text(s,11,Color.WHITE,true); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16),dp(10),dp(16),dp(10));
        t.setBackground(round(Color.argb(150,15,30,48),dp(20),Color.argb(150,255,255,255),dp(1)));
        t.setFocusable(true); t.setClickable(true);
        return t;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        return t;
    }
    private android.graphics.drawable.GradientDrawable round(int color,int radius,int stroke,int sw) {
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); d.setStroke(sw,stroke); return d;
    }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }

    class FrameBackground extends android.widget.FrameLayout {
        Paint paint=new Paint(3);
        Bitmap bitmap;
        FrameBackground(){super(MainActivity.this); setWillNotDraw(false);}
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(),h=getHeight();
            paint.setShader(new android.graphics.LinearGradient(0,0,w,h, new int[]{Color.rgb(7,20,36),Color.rgb(20,20,38),Color.rgb(54,25,43)},null,android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,paint); paint.setShader(null);
            if(wallpaperUri!=null) {
                try {
                    InputStream in=getContentResolver().openInputStream(wallpaperUri);
                    bitmap=BitmapFactory.decodeStream(in); if(in!=null)in.close();
                    if(bitmap!=null) {
                        float scale=Math.max((float)w/bitmap.getWidth(),(float)h/bitmap.getHeight());
                        float bw=bitmap.getWidth()*scale,bh=bitmap.getHeight()*scale;
                        RectF dst=new RectF((w-bw)/2,(h-bh)/2,(w+bw)/2,(h+bh)/2);
                        paint.setAlpha(160); c.drawBitmap(bitmap,null,dst,paint); paint.setAlpha(255);
                        paint.setShader(new android.graphics.LinearGradient(0,0,0,h,0x33101828,0xB0000711,android.graphics.Shader.TileMode.CLAMP));
                        c.drawRect(0,0,w,h,paint); paint.setShader(null);
                    }
                } catch(Exception ignored) {}
            }
        }
    }
}
